package com.lab.rmtbanking.creditservice.entity;

//todo delete
public class Task {
}
