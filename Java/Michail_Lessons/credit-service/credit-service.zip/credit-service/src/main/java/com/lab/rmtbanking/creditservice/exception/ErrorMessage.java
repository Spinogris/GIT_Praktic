package com.lab.rmtbanking.creditservice.exception;

public class ErrorMessage {

    public static final String TEMPORARY_UNAVAILABLE = "Service temporary unavailable";

    public static final String CREDIT_PRODUCT_NOT_FOUND = "Product was not found by this Id";

    public static final String NO_CREDIT_WITH_ID = "No credit with this id.";

    public static final String CREDIT_ORDER_STATUS = "Credit order status DECLINED or APPROVED";

    public static final String NEAREST_PAYMENT_NOT_FOUND = "Nearest payment not found";
}