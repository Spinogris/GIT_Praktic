package com.lab.rmtbanking.creditservice.entity.enums;

public enum TaskStatus {
    COMPLETED
}
