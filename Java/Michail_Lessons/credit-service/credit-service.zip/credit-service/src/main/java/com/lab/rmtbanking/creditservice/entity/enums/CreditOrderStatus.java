package com.lab.rmtbanking.creditservice.entity.enums;

public enum CreditOrderStatus {

    ACCEPTED,
    IN_REVIEW,
    DECLINED,
    APPROVED
}
