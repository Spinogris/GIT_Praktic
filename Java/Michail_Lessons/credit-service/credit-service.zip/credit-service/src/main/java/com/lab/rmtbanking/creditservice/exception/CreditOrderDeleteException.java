package com.lab.rmtbanking.creditservice.exception;

public class CreditOrderDeleteException extends RuntimeException {

    public CreditOrderDeleteException(String message) {
        super(message);
    }
}
