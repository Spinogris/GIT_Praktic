package com.lab.rmtbanking.creditservice.exception;

public class ErrorCode {

    //validation codes
    public static final String VALIDATION_FAILED = "validation_failed";
    public static final String INVALID_PATH_VARIABLE = "invalid_path_variable";

    public static final String CREDIT_NOT_FOUND = "credit_not_found";
    public static final String PRODUCT_NOT_FOUND = "product_not_found";
    public static final String CREDIT_ORDER_STATUS = "credit_order_status_declined_or_approved";
    public static final String PAYMENT_NOT_FOUND = "payment_not_found";
}