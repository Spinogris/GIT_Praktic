package com.lab.rmtbanking.creditservice.entity.enums;

public enum PaymentSystem {

    VISA,
    MASTERCARD,
    MIR,
    AMERICAN_EXPRESS
}