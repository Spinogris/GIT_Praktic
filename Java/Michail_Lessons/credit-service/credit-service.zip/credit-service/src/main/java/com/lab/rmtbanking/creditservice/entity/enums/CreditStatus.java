package com.lab.rmtbanking.creditservice.entity.enums;

public enum CreditStatus {

    IN_REVIEW,
    DECLINED,
    ACTIVE,
    CLOSED
}
