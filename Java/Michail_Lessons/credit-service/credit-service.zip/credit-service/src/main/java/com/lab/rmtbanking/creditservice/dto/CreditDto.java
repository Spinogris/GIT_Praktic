package com.lab.rmtbanking.creditservice.dto;

public class CreditDto {
}
