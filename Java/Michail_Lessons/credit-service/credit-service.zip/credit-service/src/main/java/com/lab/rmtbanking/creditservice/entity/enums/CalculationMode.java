package com.lab.rmtbanking.creditservice.entity.enums;

public enum CalculationMode {

    ANNUITY,
    DIFFERENTIATED
}
