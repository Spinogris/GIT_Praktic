package com.lab.rmtbanking.creditservice.service.impl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AccountServiceImplTest {

    @Test
    void getAccountById() {
    }

    @Test
    void getAccountTestDTO() {
    }
}