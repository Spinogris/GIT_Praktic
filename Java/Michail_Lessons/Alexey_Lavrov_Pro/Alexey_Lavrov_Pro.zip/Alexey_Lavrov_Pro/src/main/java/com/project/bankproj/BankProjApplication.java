package com.project.bankproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankProjApplication {
	public static void main(String[] args) {
		SpringApplication.run(BankProjApplication.class, args);
	}
}