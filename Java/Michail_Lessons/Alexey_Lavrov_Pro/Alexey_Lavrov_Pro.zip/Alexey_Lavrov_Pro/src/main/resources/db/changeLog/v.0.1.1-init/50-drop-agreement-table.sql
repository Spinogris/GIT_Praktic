ALTER TABLE `agreement`
    DROP CONSTRAINT `agreement_fk0`;

ALTER TABLE `agreement`
    DROP CONSTRAINT `agreement_fk1`;

DROP TABLE `agreement`;
