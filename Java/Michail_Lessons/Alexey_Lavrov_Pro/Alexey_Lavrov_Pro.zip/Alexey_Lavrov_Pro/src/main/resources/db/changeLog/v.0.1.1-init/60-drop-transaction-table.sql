ALTER TABLE `transaction`
    DROP CONSTRAINT `transaction_fk0`;

DROP TABLE `transaction`;

