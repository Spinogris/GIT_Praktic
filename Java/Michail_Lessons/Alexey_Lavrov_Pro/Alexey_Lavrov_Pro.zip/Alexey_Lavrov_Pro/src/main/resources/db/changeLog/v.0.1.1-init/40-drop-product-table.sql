ALTER TABLE `product`
    DROP CONSTRAINT `product_fk0`;
DROP TABLE  `product`;