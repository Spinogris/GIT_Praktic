ALTER TABLE `account`
    DROP CONSTRAINT `account_fk0`;
DROP TABLE `account`;