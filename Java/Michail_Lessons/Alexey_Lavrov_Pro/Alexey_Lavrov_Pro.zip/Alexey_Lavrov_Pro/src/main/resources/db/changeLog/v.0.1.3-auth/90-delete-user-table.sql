ALTER TABLE `user` DROP CONSTRAINT `user_manager_fk0`;

ALTER TABLE `user` DROP CONSTRAINT `user_client_fk0`;

DROP TABLE `user`;