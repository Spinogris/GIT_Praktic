ALTER TABLE `client`
    DROP CONSTRAINT `client_fk0`;

DROP TABLE `client`;